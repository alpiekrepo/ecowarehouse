# -*- coding: utf-8 -*-

from . import payment_acquirer
from . import payment_acquirer_method
from . import payment_icon
from . import payment_transaction
from . import provider_log
from . import res_partner
from . import account_move
